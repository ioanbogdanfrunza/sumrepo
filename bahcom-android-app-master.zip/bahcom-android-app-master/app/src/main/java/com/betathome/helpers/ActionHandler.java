package com.betathome.helpers;

public interface ActionHandler {
    void action();
}
