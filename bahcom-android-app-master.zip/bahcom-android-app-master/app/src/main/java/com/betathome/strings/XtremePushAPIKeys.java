package com.betathome.strings;

public class XtremePushAPIKeys {
    private static String sessionID = "122755482353";

    /** COM **/
    private static String comXtrmApiKey = "DZ1P36G0JRnDmlqon7pHhmCgABZwE7y3";

    /** DE **/
    private static String deXtrmApiKey = "oPJen54XxHodLAuzmi5xp_1f2mY2ItMc";

    public static String getComXtrmApiKey() {
        return comXtrmApiKey;
    }

    public static String getDeXtrmApiKey() { return deXtrmApiKey; }

    public static String getSessionID() {
        return sessionID;
    }
}
